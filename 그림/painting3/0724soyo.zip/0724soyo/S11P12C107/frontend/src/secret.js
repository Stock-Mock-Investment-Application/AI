export const secret = {
  "apiKey": "SG_e223471534b9e8bd"
}
