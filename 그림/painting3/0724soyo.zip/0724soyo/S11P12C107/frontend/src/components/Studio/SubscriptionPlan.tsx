const SubscriptionPlan = () =>{
    return (
        <div>
            구독제 플랜 페이지
        </div>
    )
}

export default SubscriptionPlan