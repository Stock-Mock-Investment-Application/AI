const TeamSetting = () =>{
    return (
        <div>
            팀설정
        </div>
    )
}

export default TeamSetting