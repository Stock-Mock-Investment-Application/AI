const StudioSetting = () => {

    return (
        <div>
            스튜디오 일반 설정
        </div>
    )
}

export default StudioSetting