import React from 'react';
import Home from './Home'; // 예를 들어 './Home'에 실제 파일 경로를 사용합니다.

const AIPaintingPage: React.FC = () => {
    return (
        <div>
            <h2>AI를 활용한 일러스트 제작</h2>
            <p>내가 만든 캐릭터의 삽화를 만들어봐요 🐇⭐</p>
            <Home />
        </div>
    );
}

export default AIPaintingPage;
