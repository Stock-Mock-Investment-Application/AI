import styled from "styled-components"

const StoryEditPage = () => {
    return (
        <>
        스튜디오 스토리 편집하는 곳 페이지
        
        </>
    )


}

export default StoryEditPage