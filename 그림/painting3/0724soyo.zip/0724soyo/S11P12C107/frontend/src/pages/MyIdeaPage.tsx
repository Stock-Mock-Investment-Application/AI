

const MyIdeaPage = () => {
    return (
        <>
        
        내 아이디어 보관함 페이지
        </>
    )


}

export default MyIdeaPage