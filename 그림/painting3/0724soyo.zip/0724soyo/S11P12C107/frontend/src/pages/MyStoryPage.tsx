

const MyStoryPage = () => {
    return (
        <>
        내 스토리 보관함 페이지
        
        </>
    )


}

export default MyStoryPage