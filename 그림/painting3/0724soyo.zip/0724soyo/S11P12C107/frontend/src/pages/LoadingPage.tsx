import styled from "styled-components"

const LoadingPage = () => {
    return (
        <>
        로딩페이지
        
        </>
    )


}

export default LoadingPage