const IdeaBoxPage = () => {

  return(

    <>
    팀 아이디어 페이지
    </>
  )
}

export default IdeaBoxPage